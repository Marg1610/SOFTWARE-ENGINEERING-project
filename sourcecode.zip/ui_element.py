# ui_element.py
import pygame
from constants import COLORS

class UIElement:
    def __init__(self, x, y, width=None, height=None):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

    def draw(self, screen, font):
        raise NotImplementedError

    def is_clicked(self, pos):
        if self.width is not None and self.height is not None:
            return self.x < pos[0] < self.x + self.width and self.y < pos[1] < self.y + self.height
        return False

class Button(UIElement):
    def __init__(self, text, x, y, width, height):
        super().__init__(x, y, width, height)
        self.text = text

    def draw(self, screen, font):
        text_surface = font.render(self.text, True, COLORS['BLACK'])
        screen.blit(text_surface, (self.x + (self.width - text_surface.get_width()) // 2, self.y + (self.height - text_surface.get_height()) // 2))
    

class Text(UIElement):
    def __init__(self, text, x, y, font_size):
        super().__init__(x, y)
        self.text = text
        self.font_size = font_size

    def draw(self, screen, font):
        text_surface = font.render(self.text, True, COLORS['BLACK'])
        screen.blit(text_surface, (self.x, self.y))

class InputBox(UIElement):
    def __init__(self, x, y, width, height, text=None):
        super().__init__(x, y, width, height)
        self.rect = pygame.Rect(x, y, width, height)
        self.color_inactive = COLORS['BLACK']
        self.color_active = COLORS['BLUE']
        self.color = self.color_inactive
        self.text = text if text is not None else ''
        self.txt_surface = None
        self.active = False

    def set_font(self, font):
        self.font = font
        self.txt_surface = self.font.render(self.text if self.text else "Крестики" if self.text == '' else "Нолики", True, self.color)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = not self.active
            else:
                self.active = False
            self.color = self.color_active if self.active else self.color_inactive
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN:
                    self.text = ''
                    self.active = False
                elif event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    if len(self.text) < 10:
                        self.text += event.unicode
                self.txt_surface = self.font.render(self.text, True, self.color)

    def draw(self, screen):
        screen.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))
        self.rect.w = max(200, self.txt_surface.get_width() + 10)
        pygame.draw.rect(screen, self.color, self.rect, 2)
