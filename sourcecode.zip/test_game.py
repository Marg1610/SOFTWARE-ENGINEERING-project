# test_game.py
import unittest
from game import Game

class TestGame(unittest.TestCase):

    def setUp(self):
        self.game = Game("Player 1", "Player 2", "Human", "Normal", 3)

    def test_check_winner_horizontal(self):
        self.game.board = [
            [1, 1, 1],
            [0, 0, 0],
            [0, 0, 0]
        ]
        self.assertTrue(self.game.check_winner(self.game.board, 1))

    def test_check_winner_vertical(self):
        self.game.board = [
            [1, 0, 0],
            [1, 0, 0],
            [1, 0, 0]
        ]
        self.assertTrue(self.game.check_winner(self.game.board, 1))

    def test_check_winner_diagonal(self):
        self.game.board = [
            [1, 0, 0],
            [0, 1, 0],
            [0, 0, 1]
        ]
        self.assertTrue(self.game.check_winner(self.game.board, 1))

    def test_check_winner_no_winner(self):
        self.game.board = [
            [1, 1, 2],
            [2, 2, 1],
            [1, 2, 1]
        ]
        self.assertFalse(self.game.check_winner(self.game.board, 1))
        self.assertFalse(self.game.check_winner(self.game.board, 2))

    def test_is_board_full(self):
        self.game.board = [
            [1, 2, 1],
            [2, 1, 2],
            [1, 2, 1]
        ]
        self.assertTrue(self.game.is_board_full(self.game.board))

    def test_is_board_not_full(self):
        self.game.board = [
            [1, 2, 1],
            [2, 1, 2],
            [1, 2, 0]
        ]
        self.assertFalse(self.game.is_board_full(self.game.board))

    def test_update_score(self):
        self.game.update_score(1)
        self.assertEqual(self.game.score[0], 1)
        self.game.update_score(2)
        self.assertEqual(self.game.score[1], 1)

    def test_new_round(self):
        self.game.board = [
            [1, 2, 1],
            [2, 1, 2],
            [1, 2, 1]
        ]
        self.game.current_player = 2
        self.game.game_over = True
        self.game.current_round = 1

        self.game.new_round()

        self.assertEqual(self.game.board, [[0, 0, 0], [0, 0, 0], [0, 0, 0]])
        self.assertEqual(self.game.current_player, 1)
        self.assertFalse(self.game.game_over)
        self.assertEqual(self.game.current_round, 2)

    def test_reset_game(self):
        self.game.board = [
            [1, 2, 1],
            [2, 1, 2],
            [1, 2, 1]
        ]
        self.game.current_player = 2
        self.game.game_over = True
        self.game.match_over = True
        self.game.current_round = 1
        self.game.score = [1, 2, 3]

        self.game.reset_game()

        self.assertEqual(self.game.board, [[0, 0, 0], [0, 0, 0], [0, 0, 0]])
        self.assertEqual(self.game.current_player, 1)
        self.assertFalse(self.game.game_over)
        self.assertFalse(self.game.match_over)
        self.assertEqual(self.game.current_round, 0)
        self.assertEqual(self.game.score, [0, 0, 0])

    def test_bot_move_hard(self):
        self.game.board = [
            [1, 2, 1],
            [2, 1, 2],
            [0, 0, 0]
        ]
        self.game.current_player = 2
        self.game.opponent_type = 'Бот'
        self.game.bot_difficulty = 'сложный'

        self.game.bot_move_hard()

        self.assertNotEqual(self.game.board, [[1, 2, 1], [2, 1, 2], [0, 0, 0]])

    def test_determine_match_winner(self):
        self.game.score = [2, 1, 0]
        self.game.determine_match_winner()
        self.assertEqual(self.game.match_game_ui['match_winner_text'].text, "Победитель матча: Player 1!")

        self.game.score = [1, 2, 0]
        self.game.determine_match_winner()
        self.assertEqual(self.game.match_game_ui['match_winner_text'].text, "Победитель матча: Player 2!")

        self.game.score = [1, 1, 1]
        self.game.determine_match_winner()
        self.assertEqual(self.game.match_game_ui['match_winner_text'].text, "Ничья!")

if __name__ == '__main__':
    unittest.main()