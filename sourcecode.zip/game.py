# game.py
import pygame
import random
import os
pygame.mixer.init()

from constants import COLORS, SCREEN_WIDTH, SCREEN_HEIGHT, TEXT_SIZE, CELL_SIZE
from ui_element import Button, Text, InputBox

def load_font(font_name, size):
    try:
        return pygame.font.SysFont("Times New Roman", TEXT_SIZE)
    except Exception as e:
        return pygame.font.Font(None, TEXT_SIZE)

    
class Game:
    def __init__(self, player1_name, player2_name, opponent_type, game_mode, rounds):
        self.player1_name = player1_name
        self.player2_name = player2_name
        self.opponent_type = opponent_type
        self.game_mode = game_mode
        self.rounds = rounds
        self.current_screen = 'main_menu'
        self.score = [0, 0, 0]  # Счет: [игрок1, игрок2, ничьи]
        self.bot_difficulty = 'Легкий'  # Сложность бота
        self.board = [[0 for _ in range(3)] for _ in range(3)]  # Игровое поле 3x3
        self.current_player = 1  # Текущий игрок (1 - крестик, 2 - нолик)
        self.current_round = 0  # Текущий раунд
        self.game_over = False  # Флаг окончания игры
        self.match_over = False  # Флаг окончания матча

        # UI элементы для главного меню
        self.main_menu_ui = {
            'title_text': Text("Крестики Нолики", 310, 50, TEXT_SIZE),
            'menu_text': Text("Главное меню", 330, 100, TEXT_SIZE),
            'new_game_button': Button("Новая игра", 300, 200, 200, 50),
            'exit_button': Button("Выход", 300, 300, 200, 50)
        }

        # UI элементы для меню выбора противника
        self.opponent_selection_ui = {
            'title_text': Text("Выбор противника", 290, 50, TEXT_SIZE),
            'two_players_button': Button("2 игрока", 300, 200, 200, 50),
            'bot_button': Button("Бот", 300, 300, 200, 50),
            'back_button': Button("Назад", 300, 400, 200, 50)
        }

        # UI элементы для меню выбора режима
        self.mode_selection_ui = {
            'title_text': Text("Выберите режим", 310, 50, TEXT_SIZE),
            'infinite_button': Button("Бесконечный", 300, 200, 200, 50),
            'match_button': Button("Матч", 300, 300, 200, 50),
            'back_button': Button("Назад", 300, 400, 200, 50)
        }

        # UI элементы для меню выбора длительности матча
        self.match_duration_ui = {
            'title_text': Text("Выберите количество раундов", 230, 50, TEXT_SIZE),
            'one_round_button': Button("1", 300, 200, 200, 50),
            'three_rounds_button': Button("3", 300, 300, 200, 50),
            'five_rounds_button': Button("5", 300, 400, 200, 50),
            'back_button': Button("Назад", 300, 500, 200, 50)
        }

        # UI элементы для меню выбора сложности бота
        self.bot_difficulty_ui = {
            'title_text': Text("Выберите сложность", 280, 50, TEXT_SIZE),
            'easy_button': Button("Легкий", 300, 200, 200, 50),
            'hard_button': Button("Сложный", 300, 300, 200, 50),
            'back_button': Button("Назад", 300, 400, 200, 50)
        }

        # UI элементы для меню ввода имен игроков
        self.player_names_ui = {
            'title_text': Text("Введите имена игроков (необязательно)", 180, 50, TEXT_SIZE),
            'player1_input': InputBox(300, 200, 200, 50, text='Крестики'),
            'player2_input': InputBox(300, 300, 200, 50, text='Нолики'),
            'start_button': Button("Начать", 300, 400, 200, 50),
            'back_button': Button("Назад", 300, 500, 200, 50)
        }

        # UI элементы для игрового экрана в бесконченом режиме
        self.inf_game_ui = {
            'round_text': Text("Раунд: 1", 650, 30, TEXT_SIZE),
            'player1_score_text': Text(f"{self.player1_name}: {self.score[0]}", 650, 100, TEXT_SIZE),
            'player2_score_text': Text(f"{self.player2_name}: {self.score[1]}", 650, 150, TEXT_SIZE),
            'draws_text': Text(f"Ничьи: {self.score[2]}", 650, 200, TEXT_SIZE),
            'current_turn_text': Text("Текущий ход: Крестики", 10, 10, TEXT_SIZE),
            'continue_button': Button("Продолжить", 650, 450, 150, 50),
            'menu_button': Button("В меню", 650, 550, 150, 50)
        }

        # UI элементы для игрового экрана в режиме матча
        self.match_game_ui = {
            'round_text': Text("Раунд: 1 из 3", 650, 30, TEXT_SIZE),
            'player1_score_text': Text(f"{self.player1_name}: {self.score[0]}", 650, 100, TEXT_SIZE),
            'player2_score_text': Text(f"{self.player2_name}: {self.score[1]}", 650, 150, TEXT_SIZE),
            'draws_text': Text(f"Ничьи: {self.score[2]}", 650, 200, TEXT_SIZE),
            'current_turn_text': Text("Текущий ход: Крестики", 10, 10, TEXT_SIZE),
            'continue_button': Button("Продолжить", 650, 450, 150, 50),
            'menu_button': Button("В меню", 650, 550, 150, 50),
            'match_winner_text': Text("Победитель матча: Крестики", 10, 50, TEXT_SIZE),
        }

        # Инициализация звуков
        pygame.mixer.init()
        base_path = os.path.dirname(os.path.abspath(__file__))
        mp3_path = os.path.join(base_path, 'sounds/paper.mp3')
        self.paper_sound = pygame.mixer.Sound(mp3_path)

    def play_sound(self):
        self.paper_sound.play()
    # ------------------------------------------------------------------
    # Отрисовка элементов интерфейса
    # ------------------------------------------------------------------

    def draw_main_menu(self, screen, font):
        for key, element in self.main_menu_ui.items():
            if isinstance(element, Text):
                element.draw(screen, font)
            elif isinstance(element, Button):
                element.draw(screen, font)

    def draw_opponent_selection(self, screen, font):
        for key, element in self.opponent_selection_ui.items():
            if isinstance(element, Text):
                element.draw(screen, font)
            elif isinstance(element, Button):
                element.draw(screen, font)

    def draw_mode_selection(self, screen, font):
        for key, element in self.mode_selection_ui.items():
            if isinstance(element, Text):
                element.draw(screen, font)
            elif isinstance(element, Button):
                element.draw(screen, font)

    def draw_match_duration(self, screen, font):
        for key, element in self.match_duration_ui.items():
            if isinstance(element, Text):
                element.draw(screen, font)
            elif isinstance(element, Button):
                element.draw(screen, font)

    def draw_bot_difficulty(self, screen, font):
        for key, element in self.bot_difficulty_ui.items():
            if isinstance(element, Text):
                element.draw(screen, font)
            elif isinstance(element, Button):
                element.draw(screen, font)

    def draw_player_names(self, screen, font):
        for key, element in self.player_names_ui.items():
            if isinstance(element, Text):
                element.draw(screen, font)
            elif isinstance(element, Button):
                element.draw(screen, font)
            elif isinstance(element, InputBox):
                element.draw(screen)

    def draw_grid(self, screen, start_x, start_y, cell_size):
        for i in range(4):
            pygame.draw.line(screen, COLORS['BLACK'], (start_x + i * cell_size, start_y), (start_x + i * cell_size, start_y + 3 * cell_size), 5)
            pygame.draw.line(screen, COLORS['BLACK'], (start_x, start_y + i * cell_size), (start_x + 3 * cell_size, start_y + i * cell_size), 5)

    def draw_x(self, screen, x, y, cell_size):
        pygame.draw.line(screen, COLORS['RED'], (x + 10, y + 10), (x + cell_size - 10, y + cell_size - 10), 10)
        pygame.draw.line(screen, COLORS['RED'], (x + cell_size - 10, y + 10), (x + 10, y + cell_size - 10), 10)
        pygame.draw.line(screen, (150, 0, 0), (x + 15, y + 15), (x + cell_size - 5, y + cell_size - 5), 10)
        pygame.draw.line(screen, (150, 0, 0), (x + cell_size - 5, y + 15), (x + 15, y + cell_size - 5), 10)

    def draw_o(self, screen, x, y, cell_size):
        pygame.draw.circle(screen, COLORS['BLUE'], (x + cell_size // 2, y + cell_size // 2), cell_size // 2 - 10, 10)
        pygame.draw.circle(screen, (0, 0, 150), (x + cell_size // 2 + 5, y + cell_size // 2 + 5), cell_size // 2 - 10, 10)

    def draw_inf_game_screen(self, screen, font):
        # Обновление текста на игровом экране в режиме бесконечной игры
        self.inf_game_ui['round_text'].text = f"Раунд: {self.current_round + 1}"
        self.inf_game_ui['player1_score_text'].text = f"{self.player1_name}: {self.score[0]}"
        self.inf_game_ui['player2_score_text'].text = f"{self.player2_name}: {self.score[1]}"
        self.inf_game_ui['draws_text'].text = f"Ничьи: {self.score[2]}"
        turn_text = f"Крестики" if self.current_player == 1 else f"Нолики"
        if self.game_over:
            if self.check_winner(self.board, 1):
                turn_text = f"Победитель: {self.player1_name}!"
            elif self.check_winner(self.board, 2):
                turn_text = f"Победитель: {self.player2_name}!"
            else:
                turn_text = "Ничья!"
        self.inf_game_ui['current_turn_text'].text = f"Текущий ход: {turn_text}"

        for key, element in self.inf_game_ui.items():
            if isinstance(element, Text):
                element.draw(screen, font)
            elif isinstance(element, Button):
                if self.game_over:
                    element.draw(screen, font)

    def draw_match_game_screen(self, screen, font):
        # Обновление текста на игровом экране в режиме матча
        self.match_game_ui['round_text'].text = f"Раунд: {self.current_round + 1} из {self.rounds}"
        self.match_game_ui['player1_score_text'].text = f"{self.player1_name}: {self.score[0]}"
        self.match_game_ui['player2_score_text'].text = f"{self.player2_name}: {self.score[1]}"
        self.match_game_ui['draws_text'].text = f"Ничьи: {self.score[2]}"
        turn_text = "Крестики" if self.current_player == 1 else "Нолики"
        if self.game_over:
            if self.check_winner(self.board, 1):
                turn_text = f"Победитель раунда - {self.player1_name}!"
            elif self.check_winner(self.board, 2):
                turn_text = f"Победитель раунда - {self.player2_name}!"
            else:
                turn_text = "Ничья!"
        self.match_game_ui['current_turn_text'].text = f"Текущий ход: {turn_text}"

        self.match_game_ui['round_text'].draw(screen, font)
        self.match_game_ui['player1_score_text'].draw(screen, font)
        self.match_game_ui['player2_score_text'].draw(screen, font)
        self.match_game_ui['draws_text'].draw(screen, font)
        self.match_game_ui['current_turn_text'].draw(screen, font)
        if self.game_over and not self.match_over:
            self.match_game_ui['continue_button'].draw(screen, font)
        if self.match_over:
            self.match_game_ui['menu_button'].draw(screen, font)
            self.match_game_ui['match_winner_text'].draw(screen, font)

    def draw_background(self, screen):
        screen.fill(COLORS['WHITE'])
        for i in range(0, SCREEN_WIDTH, CELL_SIZE//2):
            pygame.draw.line(screen, COLORS['LIGHT_BLUE'], (i, 0), (i, SCREEN_HEIGHT), 2)
        for i in range(0, SCREEN_HEIGHT, CELL_SIZE//2):
            pygame.draw.line(screen, COLORS['LIGHT_BLUE'], (0, i), (SCREEN_WIDTH, i), 2)

    # ------------------------------------------------------------------
    # Логика игры
    # ------------------------------------------------------------------

    def determine_match_winner(self):
        if self.score[0] > self.score[1]:
            self.match_game_ui['match_winner_text'].text = f"Победитель матча: {self.player1_name}!"
        elif self.score[1] > self.score[0]:
            self.match_game_ui['match_winner_text'].text = f"Победитель матча: {self.player2_name}!"
        else:
            if self.score[2] > 0:
                self.match_game_ui['match_winner_text'].text = "Ничья!"
            else:
                self.match_game_ui['match_winner_text'].text = "Ничья!"

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if self.current_screen == 'main_menu':
                    if self.main_menu_ui['new_game_button'].is_clicked(pos):
                        self.current_screen = 'opponent_selection'
                    elif self.main_menu_ui['exit_button'].is_clicked(pos):
                        return False
                elif self.current_screen == 'opponent_selection':
                    if self.opponent_selection_ui['two_players_button'].is_clicked(pos):
                        self.opponent_type = '2 игрока'
                        self.current_screen = 'player_names'
                    elif self.opponent_selection_ui['bot_button'].is_clicked(pos):
                        self.opponent_type = 'Бот'
                        self.player1_name = 'Крестики'
                        self.player2_name = 'Нолики'
                        self.current_screen = 'bot_difficulty'
                    elif self.opponent_selection_ui['back_button'].is_clicked(pos):
                        self.current_screen = 'main_menu'
                elif self.current_screen == 'mode_selection':
                    if self.mode_selection_ui['infinite_button'].is_clicked(pos):
                        self.game_mode = 'infinite'
                        self.current_screen = 'game'  # Переход к игре
                    elif self.mode_selection_ui['match_button'].is_clicked(pos):
                        self.game_mode = 'match'
                        self.current_screen = 'match_duration'
                    elif self.mode_selection_ui['back_button'].is_clicked(pos):
                        self.current_screen = 'opponent_selection'
                elif self.current_screen == 'match_duration':
                    if self.match_duration_ui['one_round_button'].is_clicked(pos):
                        self.rounds = 1
                        self.current_screen = 'game'  # Переход к игре
                    elif self.match_duration_ui['three_rounds_button'].is_clicked(pos):
                        self.rounds = 3
                        self.current_screen = 'game'  # Переход к игре
                    elif self.match_duration_ui['five_rounds_button'].is_clicked(pos):
                        self.rounds = 5
                        self.current_screen = 'game'  # Переход к игре
                    elif self.match_duration_ui['back_button'].is_clicked(pos):
                        self.current_screen = 'mode_selection'
                elif self.current_screen == 'bot_difficulty':
                    if self.bot_difficulty_ui['easy_button'].is_clicked(pos):
                        self.bot_difficulty = 'Легкий'
                        self.current_screen = 'mode_selection'
                    elif self.bot_difficulty_ui['hard_button'].is_clicked(pos):
                        self.bot_difficulty = 'Сложный'
                        self.current_screen = 'mode_selection'
                    elif self.bot_difficulty_ui['back_button'].is_clicked(pos):
                        self.current_screen = 'opponent_selection'
                elif self.current_screen == 'player_names':
                    if self.player_names_ui['start_button'].is_clicked(pos):
                        self.player1_name = self.player_names_ui['player1_input'].text if self.player_names_ui['player1_input'].text else 'Крестики'
                        self.player2_name = self.player_names_ui['player2_input'].text if self.player_names_ui['player2_input'].text else 'Нолики'
                        self.current_screen = 'mode_selection'
                    elif self.player_names_ui['back_button'].is_clicked(pos):
                        self.current_screen = 'opponent_selection'
                elif self.current_screen == 'game':
                    if self.game_mode == 'infinite':
                        if self.game_over:
                            if self.inf_game_ui['continue_button'].is_clicked(pos):
                                self.new_round()
                            elif self.inf_game_ui['menu_button'].is_clicked(pos):
                                self.reset_game()
                                self.current_screen = 'main_menu'
                        else:
                            # Обработка щелчков мыши на игровом поле
                            start_x = (SCREEN_WIDTH - 3 * CELL_SIZE) // 2
                            start_y = (SCREEN_HEIGHT - 3 * CELL_SIZE) // 2
                            row = (pos[1] - start_y) // CELL_SIZE
                            col = (pos[0] - start_x) // CELL_SIZE
                            if 0 <= row < 3 and 0 <= col < 3 and self.board[row][col] == 0:
                                self.board[row][col] = self.current_player
                                if self.check_winner(self.board, self.current_player):
                                    self.update_score(self.current_player)
                                    self.game_over = True
                                elif self.is_board_full(self.board):
                                    self.score[2] += 1
                                    self.game_over = True
                                else:
                                    self.current_player = 3 - self.current_player  # Смена игрока
                                    self.make_move()
                    elif self.game_mode == 'match':
                            if self.game_over:
                                if self.current_round + 1 == self.rounds or self.score[0] == self.rounds - 1 or self.score[1] == self.rounds - 1:
                                    self.match_over = True
                                    self.determine_match_winner()
                                else:
                                    self.new_round()

                                if self.inf_game_ui['menu_button'].is_clicked(pos):
                                    self.reset_game()
                                    self.current_screen = 'main_menu'
                            else:
                                # Обработка щелчков мыши на игровом поле
                                start_x = (SCREEN_WIDTH - 3 * CELL_SIZE) // 2
                                start_y = (SCREEN_HEIGHT - 3 * CELL_SIZE) // 2
                                row = (pos[1] - start_y) // CELL_SIZE
                                col = (pos[0] - start_x) // CELL_SIZE
                                if 0 <= row < 3 and 0 <= col < 3 and self.board[row][col] == 0:
                                    self.board[row][col] = self.current_player
                                    if self.check_winner(self.board, self.current_player):
                                        self.update_score(self.current_player)
                                        self.game_over = True
                                    elif self.is_board_full(self.board):
                                        self.score[2] += 1
                                        self.game_over = True
                                    else:
                                        self.current_player = 3 - self.current_player  # Смена игрока
                                        self.make_move()

            if self.current_screen == 'player_names':
                self.player_names_ui['player1_input'].handle_event(event)
                self.player_names_ui['player2_input'].handle_event(event)
        return True

    def make_move(self):
        self.paper_sound.play()
        if self.current_player == 2 and self.opponent_type == 'Бот':
            if self.bot_difficulty == 'Легкий':
                self.bot_move_easy()
            elif self.bot_difficulty == 'Сложный':
                self.bot_move_hard()
        elif self.current_player == 2 and self.opponent_type == '2 игрока':
            self.player_move()

    def player_move(self):
        pass

    def bot_move_easy(self):
        # Легкий бот: случайная свободная клетка
        empty_cells = [(row, col) for row in range(3) for col in range(3) if self.board[row][col] == 0]
        if empty_cells:
            row, col = random.choice(empty_cells)
            self.board[row][col] = 2
            if self.check_winner(self.board, 2):
                self.update_score(2)
                self.game_over = True
            elif self.is_board_full(self.board):
                self.score[2] += 1
                self.game_over = True
            else:
                self.current_player = 1

    def minimax(self, board, depth, is_maximizing, alpha, beta):
        if self.check_winner(board, 2):
            return 1
        if self.check_winner(board, 1):
            return -1
        if self.is_board_full(board):
            return 0

        if is_maximizing:
            best_score = -float('inf')
            for row in range(3):
                for col in range(3):
                    if board[row][col] == 0:
                        board[row][col] = 2
                        score = self.minimax(board, depth + 1, False, alpha, beta)
                        board[row][col] = 0
                        best_score = max(score, best_score)
                        alpha = max(alpha, best_score)
                        if beta <= alpha:
                            break
                if beta <= alpha:
                    break
            return best_score
        else:
            best_score = float('inf')
            for row in range(3):
                for col in range(3):
                    if board[row][col] == 0:
                        board[row][col] = 1
                        score = self.minimax(board, depth + 1, True, alpha, beta)
                        board[row][col] = 0
                        best_score = min(score, best_score)
                        beta = min(beta, best_score)
                        if beta <= alpha:
                            break
                if beta <= alpha:
                    break
            return best_score

    def bot_move_hard(self):
        # Сложный бот: алгоритм Minimax с альфа-бета отсечением
        best_score = -float('inf')
        best_move = None
        alpha = -float('inf')
        beta = float('inf')
        for row in range(3):
            for col in range(3):
                if self.board[row][col] == 0:
                    self.board[row][col] = 2
                    score = self.minimax(self.board, 0, False, alpha, beta)
                    self.board[row][col] = 0
                    if score > best_score:
                        best_score = score
                        best_move = (row, col)
        if best_move:
            row, col = best_move
            self.board[row][col] = 2
            if self.check_winner(self.board, 2):
                self.update_score(2)
                self.game_over = True
            elif self.is_board_full(self.board):
                self.score[2] += 1
                self.game_over = True
            else:
                self.current_player = 1

    def check_winner(self, board, player):
        # Проверка победителя
        for row in range(3):
            if all(board[row][col] == player for col in range(3)):
                return True
        for col in range(3):
            if all(board[row][col] == player for row in range(3)):
                return True
        if all(board[i][i] == player for i in range(3)):
            return True
        if all(board[i][2 - i] == player for i in range(3)):
            return True
        return False

    def is_board_full(self, board):
        # Проверка, заполнено ли поле
        return all(board[row][col] != 0 for row in range(3) for col in range(3))

    def update_score(self, player):
        if player == 1:
            self.score[0] += 1
        elif player == 2:
            self.score[1] += 1

    def new_round(self):
        self.board = [[0 for _ in range(3)] for _ in range(3)]
        self.current_player = 1
        self.game_over = False
        self.current_round += 1

    def reset_game(self):
        self.board = [[0 for _ in range(3)] for _ in range(3)]
        self.current_player = 1
        self.game_over = False
        self.match_over = False
        self.current_round = 0
        self.score = [0, 0, 0]

    def start_game(self):
        pygame.init()
        pygame.mixer.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("XOX Game")
        font = load_font('Segoe Print', TEXT_SIZE)

        # Инициализация шрифта для полей ввода
        self.player_names_ui['player1_input'].set_font(font)
        self.player_names_ui['player2_input'].set_font(font)

        running = True
        while running:
            running = self.handle_events()

            self.screen.fill(COLORS['GREEN1'])

            if self.current_screen == 'main_menu':
                self.draw_main_menu(self.screen, font)
            elif self.current_screen == 'opponent_selection':
                self.draw_opponent_selection(self.screen, font)
            elif self.current_screen == 'mode_selection':
                self.draw_mode_selection(self.screen, font)
            elif self.current_screen == 'match_duration':
                self.draw_match_duration(self.screen, font)
            elif self.current_screen == 'bot_difficulty':
                self.draw_bot_difficulty(self.screen, font)
            elif self.current_screen == 'player_names':
                self.draw_player_names(self.screen, font)
            elif self.current_screen == 'game':

                self.draw_background(self.screen)
                # Рассчитываем начальные координаты для рисования сетки
                start_x = (SCREEN_WIDTH - 3 * CELL_SIZE) // 2
                start_y = (SCREEN_HEIGHT - 3 * CELL_SIZE) // 2
                self.draw_grid(self.screen, start_x, start_y, CELL_SIZE)

                # Рисуем фигуры на игровом поле
                for row in range(3):
                    for col in range(3):
                        if self.board[row][col] == 1:
                            self.draw_x(self.screen, start_x + col * CELL_SIZE, start_y + row * CELL_SIZE, CELL_SIZE)
                        elif self.board[row][col] == 2:
                            self.draw_o(self.screen, start_x + col * CELL_SIZE, start_y + row * CELL_SIZE, CELL_SIZE)

                # Рисуем элементы игрового экрана
                if self.game_mode == 'infinite':
                    self.draw_inf_game_screen(self.screen, font)
                elif self.game_mode == 'match':
                    self.draw_match_game_screen(self.screen, font)

            pygame.display.flip()

        pygame.quit()
