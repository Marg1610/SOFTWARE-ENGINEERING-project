# main.py
from game import Game

if __name__ == "__main__":
    game = Game("Игрок 1", "Игрок 2", "Человек", "Обычный", 3)
    game.start_game()
