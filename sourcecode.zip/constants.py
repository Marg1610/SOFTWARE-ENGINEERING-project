# constants.py
COLORS = {
    'BLACK': (0, 0, 0),
    'WHITE': (255, 255, 255),
    'RED': (244,68,36),
    'BLUE': (65, 75, 178),
    'GREEN1': (144,212,172),
    'GREEN2': (111, 189, 143),
    'LIGHT_BLUE': (210, 231, 250),
    'DARK_BLUE': (6, 0, 87),
}
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
TEXT_SIZE = 25
CELL_SIZE = 150  # Размер клетки
